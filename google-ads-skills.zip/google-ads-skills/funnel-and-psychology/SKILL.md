---
name: google-ads-funnel-and-psychology
description: Split Google Ads keywords into top, middle and bottom of funnel, work out how each stage affects conversion rate and ROAS, and write ads and landing pages that use customer biases honestly. Use with google-ads-core and an industry skill when planning budgets, keyword lists or ad copy.
---

# Keyword funnel, ROAS and customer biases

Load `core/SKILL.md` first. Each industry skill has its own funnel table and bias examples. This file explains the method behind them.

## Part 1: the three keyword funnels

People search differently depending on how close they are to buying. Sort every keyword into one of three stages.

| Stage | What the searcher is doing | Typical words | Example (plumbing) |
| --- | --- | --- | --- |
| Top of funnel (TOFU) | Learning about a problem. Not ready to hire | what is, how to, why, signs of, ideas, guide | why is my water heater leaking |
| Middle of funnel (MOFU) | Comparing options and prices | cost, price, best, vs, reviews, compare, options | water heater replacement cost |
| Bottom of funnel (BOFU) | Ready to hire now | near me, [city], book, hire, quote, emergency, company, service | water heater repair near me |

Brand searches (your company name) sit at the very bottom. They convert best and cost least, so always run a brand campaign.

### How to sort a keyword

Ask one question: if this person clicked and landed on a booking page, would they book today?

- Yes, often: BOFU
- Maybe, after comparing: MOFU
- No, they want information: TOFU

When unsure, check the search results page for the keyword. If Google shows service ads, a map pack and company sites, it's BOFU. If it shows articles, videos and "People also ask", it's TOFU.

## Part 2: how each stage affects conversion rate and ROAS

### The formulas

```
conversion rate   = leads / clicks
cost per lead     = CPC / conversion rate
cost per client   = cost per lead / close rate
revenue per click = conversion rate x close rate x client value
ROAS              = revenue per click / CPC
```

ROAS above 1 means ads bring back more revenue than they cost. Whether that's profitable depends on the business's margin. A 3x ROAS is great for a service with 70% margin and a loss for a product with 20% margin.

### Worked example

Same business, same client value of $2,000. The numbers are illustrative only, to show the pattern. Use your own account data and Keyword Planner CPCs.

| Stage | CPC | Conversion rate | Close rate | Cost per lead | Cost per client | ROAS |
| --- | --- | --- | --- | --- | --- | --- |
| BOFU | $8 | 8% | 30% | $100 | $333 | 6.0x |
| MOFU | $5 | 3% | 20% | $167 | $833 | 2.4x |
| TOFU | $2 | 0.5% | 10% | $400 | $4,000 | 0.5x |

What this shows:

- BOFU clicks cost the most and still give the best ROAS, because conversion rate and close rate rise faster than CPC.
- TOFU clicks look cheap but are the most expensive way to get a client from Search directly.
- Moving budget from TOFU to BOFU usually raises account conversion rate and ROAS right away.

### Why still spend on MOFU and TOFU

BOFU volume runs out. In a single city there are only so many "dentist near me" searches a month. Once BOFU campaigns are getting most of the available impressions (check Search impression share: lost to budget near 0%, lost to rank low), more BOFU spend buys nothing.

MOFU and TOFU then do three jobs:

1. They reach people before competitors do, so your brand is the one they search for later.
2. They build remarketing lists (check health and other restricted categories first).
3. They feed brand searches, which have the highest ROAS of all.

Last-click reports give MOFU and TOFU almost no credit. Judge them with:

- Data-driven attribution in Google Ads, and the "assisted conversions" or conversion path reports
- Brand search volume over time
- A longer conversion window (60 to 90 days for high-value services)
- Holdout tests: pause TOFU in one area for a month and compare brand searches and leads with a similar area

### Budget split by stage

| Situation | BOFU | MOFU | TOFU |
| --- | --- | --- | --- |
| New account or budget under about $1,500 a month | 90 to 100% | 0 to 10% | 0% |
| BOFU impression share above about 80%, budget left over | 60 to 70% | 20 to 30% | about 10% |
| Brand-building goal, large budget, long sales cycle | 50% | 30% | 20% |

These are starting points, not rules. Move money toward whatever stage brings clients at a cost per client the business can afford.

### Bidding and structure by stage

| | BOFU | MOFU | TOFU |
| --- | --- | --- | --- |
| Campaign | Search, its own campaign | Search, its own campaign | Search with tight CPC caps, or Demand Gen and YouTube |
| Match types | Exact and phrase | Phrase, then broad with smart bidding | Phrase and broad |
| Bidding | Target CPA or Target ROAS once data allows | Maximize conversions, or Target CPA set higher than BOFU | Maximize clicks with a cap, or Maximize conversions on a micro-conversion |
| Primary conversion | Call, booking, form, closed client | Same, plus quote requests | Tool use, guide download, email sign-up (as the campaign's own goal) |
| Landing page | Service page with phone and form above the fold | Pricing page, comparison page, reviews | Guide, calculator, checklist, with a soft offer |
| Offer | Book now, free quote, same-day visit | Price range, free estimate, case review | Free checklist, calculator, short video |

Keep each stage in its own campaign. If BOFU and TOFU share a campaign, smart bidding moves money to whichever is cheaper per conversion and the stages blur.

### Common funnel mistakes

1. Mixing TOFU and BOFU keywords in one ad group with one ad. Neither gets the right message.
2. Judging TOFU by last-click ROAS and cutting it, then wondering why brand searches fall.
3. Spending on TOFU before BOFU impression share is high.
4. Sending TOFU clicks to a hard "book now" page. They aren't ready and leave.
5. Counting micro-conversions (downloads, tool use) as primary in BOFU campaigns. Bidding chases cheap downloads instead of clients.

## Part 3: customer biases in ads and landing pages

People don't decide purely on logic. These are patterns in how most people judge risk, value and trust. Using them well makes a true offer easier to understand and act on.

### The honesty rule

Only use a bias with a true claim. Fake scarcity, fake countdown timers, invented reviews or made-up "was" prices break Google's misleading content policy and Canada's Competition Act rules on false or misleading representations. They also break most professional regulators' rules. Every example below assumes the claim is real.

Some regulators restrict specific tactics. Dental colleges limit testimonials. Immigration and legal regulators ban outcome guarantees. Check the industry skill before using social proof or risk reversal.

### Bias list

| Bias | What it means | Where to use it | Funnel stage |
| --- | --- | --- | --- |
| Loss aversion | People feel losses about twice as strongly as gains | Headlines framed around what they could lose or miss | BOFU, MOFU |
| Social proof | People follow what others like them did | Review counts, client numbers, "most chosen" plan | All |
| Authority | People trust licensed experts and credentials | Licence numbers, years in practice, memberships | BOFU, MOFU |
| Anchoring | The first number seen sets the frame for the rest | Show the full-service price before the basic one, or the cost of the problem before your fee | MOFU |
| Zero-risk bias | People prefer removing a risk completely over reducing it | Free consultation, no-obligation quote, cancel anytime | BOFU |
| Reciprocity | People want to return a favour | Free tool, checklist or review first, offer second | TOFU, MOFU |
| Commitment and consistency | A small yes leads to a bigger yes | Two-step forms: easy question first, contact details second | BOFU |
| Scarcity (real only) | Limited things seem more valuable | Real capacity: routes, appointment slots, intake limits | BOFU |
| Urgency (real only) | Deadlines push action | Real deadlines: season start, renewal dates, government deadlines | BOFU, MOFU |
| Specificity | Precise numbers seem more believable than round ones | "Since 2019", "15-minute call", "312 reviews" | All |
| Choice overload | Too many options stop people deciding | 2 to 3 packages, one clear call to action per page | MOFU, BOFU |
| Decoy effect | A third option makes one choice look better | Three-tier pricing where the middle tier is the best value | MOFU |
| Framing | The same fact lands differently depending on wording | "$3 a day" vs "$1,095 a year"; "9 in 10 clients" vs "10% didn't" | MOFU |
| Default effect | People stick with the pre-selected option | Pre-select the recommended package or appointment type | BOFU |
| Ambiguity aversion | People avoid unclear costs and steps | Show price ranges, list the steps, say what happens after the form | BOFU, MOFU |

### Example headlines by bias

Generic examples. Each industry skill has its own. All under 30 characters.

```headlines
Don't Overpay at Renewal
Trusted by 500+ GTA Families
Licensed Since 2019
Free 15-Min Consultation
No-Obligation Quote
Only 6 Routes Left in Area
Book Before Dec 1 Pricing
Fixed Price, No Surprises
See Our 3 Simple Steps
Most Clients Pick Standard
```

Replace numbers, dates and claims with ones that are true for the business.

### How biases map to the funnel

| Stage | Main job of the message | Biases that fit best |
| --- | --- | --- |
| TOFU | Earn attention and trust without asking for much | Reciprocity, specificity, authority |
| MOFU | Help them compare and choose you | Anchoring, social proof, framing, decoy, ambiguity aversion |
| BOFU | Remove the last doubt and get the call or booking | Zero-risk, loss aversion, real scarcity and urgency, commitment, default |

### Effect on conversion rate and ROAS

Biases mostly change conversion rate, not CPC (though better click-through rate can lower CPC through ad rank). Going back to the formulas: if a clearer zero-risk offer lifts BOFU conversion rate from 8% to 10% at the same $8 CPC, cost per lead drops from $100 to $80 and ROAS rises from 6.0x to 7.5x in the worked example. That's why testing offers and page copy often beats raising bids.

Test one bias at a time so you know what caused a change:

1. Use ad variations or experiments in Google Ads for ad copy.
2. Use an A/B test tool or two landing pages split by URL for page changes.
3. Run each test until each version has at least 100 clicks and a few dozen conversions, or the result is noise.
4. Watch lead quality, not just lead count. Some urgency messages bring more leads who never close.
