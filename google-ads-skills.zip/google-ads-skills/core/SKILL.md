---
name: google-ads-core
description: Set up, structure, track and manage a Google Ads account for a local service business. Use for any Google Ads build, audit or weekly review, and load the matching industry skill alongside it.
---

# Google Ads core

This skill covers the parts of Google Ads that are the same for every service business. Each industry folder in this repo adds keywords, ad copy, negatives and policy notes for that industry. Use this file first, then the industry file. For keyword funnel stages, ROAS math and customer biases, also load `funnel-and-psychology/SKILL.md`.

## Before you build anything

Get answers to these from the business owner. If you skip this, the campaign gets built around guesses.

1. What is one lead worth? Ask for average job value and what share of leads become paying clients.
2. What counts as a lead: a phone call, a form, a booking, or all three?
3. Which cities or postal codes do they actually serve?
4. What hours can someone answer the phone?
5. What is the monthly budget, and is it fixed or can it grow if leads come in?
6. Who follows up on leads, and how fast? Slow follow-up kills more campaigns than bad ads.

Work out a target cost per lead from the first two answers:

```
max cost per lead = average job value x close rate x share of revenue you can spend on ads
example: $2,000 job x 25% close rate x 20% = $100 max cost per lead
```

## Conversion tracking

Do this before launch. Without it, smart bidding has nothing to learn from and you can't tell what works.

| What to track | How | Count |
| --- | --- | --- |
| Calls from ads | Call assets with Google forwarding numbers, minimum call length 60 seconds | One |
| Calls from the website | Website call conversion (Google forwarding number swapped on the page) | One |
| Form submissions | Thank-you page or a GTM form submit event | One |
| Online bookings | Booking confirmation page or the booking tool's event (TidyCal, Calendly, Acuity) | One |
| Phone number clicks on mobile | GTM click event on tel: links. Secondary only | One |
| Closed clients | Offline conversion import from your CRM using GCLID or enhanced conversions for leads | One |

Rules:

- Set calls, forms and bookings as primary conversions. Set tel: clicks and page views as secondary so they don't confuse bidding.
- Turn on enhanced conversions for leads. It improves matching when cookies are blocked.
- If you can import closed clients from the CRM, do it. Bidding on real sales beats bidding on form fills.

## Account structure

Start simple. Small budgets split across many campaigns never collect enough data.

1. One Search campaign per service line that has its own budget or margin. Most small businesses need one to three.
2. Inside each campaign, one ad group per tight keyword theme (5 to 20 keywords that mean the same thing).
3. Add Performance Max only after Search has about 30 conversions a month and tracking is clean. PMax with bad tracking spends money on junk leads.
4. Leave Display and Search Partners off at launch. Test them later on their own.

## Settings checklist

- Location: "Presence: people in or regularly in your targeted locations". The default "presence or interest" setting shows ads to people outside the service area.
- Language: English plus any language your clients search in. Write ads in that language too.
- Ad schedule: run ads only when someone can answer the phone, unless forms and bookings work 24/7.
- Networks: Search only at launch.
- Auto-apply recommendations: turn off. Review them by hand.
- Automatically created assets: review before allowing. They can write claims your client can't make.

## Keywords and match types

- Use phrase match and exact match at launch. Add broad match only once smart bidding has conversion data.
- Build keywords around intent: service + location, service + "near me", emergency or urgent terms, price terms.
- Keep "how to", "what is" and research terms out of lead campaigns. They bring readers, not buyers.

## Universal negative keywords

Add these to a shared negative list for every service business. Review against the client's offer first. A training school would need "course" and "training".

```
jobs
job
careers
career
hiring
salary
salaries
wage
resume
internship
volunteer
free
diy
how to
course
courses
training
certification
template
pdf
reddit
wikipedia
definition
meaning
youtube
used
second hand
```

## Responsive search ads

Limits:

- Headlines: up to 15, max 30 characters each. At least 3 required.
- Descriptions: up to 4, max 90 characters each. At least 2 required.
- Paths: 2 fields, 15 characters each.

Write headlines in these groups so Google can mix them:

| Group | How many | Example |
| --- | --- | --- |
| Service + location | 3 to 4 | Plumber in Mississauga |
| Offer or price | 2 to 3 | Free 15-Min Phone Consult |
| Proof | 2 to 3 | 500+ Jobs Done Since 2019 |
| Speed or availability | 2 | Same-Day Appointments |
| Call to action | 2 | Call Now for a Quote |
| Brand | 1 | Brand name |

Pin only when you must. Pinning one headline in position 1 is fine for a required disclaimer or licence number. Pinning many headlines lowers ad strength and reach.

## Assets

| Asset | Limit | Use |
| --- | --- | --- |
| Sitelinks | 25 characters text, two 35-character description lines | 4 to 8 links to service pages, pricing, booking, about |
| Callouts | 25 characters | 4 to 10 short facts: licensed, hours, languages, payment options |
| Structured snippets | 25 characters per value, at least 3 values | "Services:" list |
| Call | Phone number | Always on during business hours |
| Location | Linked Google Business Profile | Always for local businesses |
| Image | Square and landscape | Real photos of staff or work beat stock photos |
| Lead form | Native form in the ad | Test it; quality is often lower than website forms |

## Bidding

Move through these stages:

1. Launch: Maximize clicks with a max CPC cap, or Manual CPC. Goal is traffic and first conversions.
2. After about 15 to 30 conversions in 30 days: Maximize conversions.
3. After about 30 or more conversions in 30 days with stable cost per lead: Target CPA set near your actual average.
4. If you import closed sales with values: Maximize conversion value or Target ROAS.

Don't change bid strategy and budget at the same time. Give each change one to two weeks.

## Budget

Rough check that a budget can work:

```
daily budget should cover at least 10 clicks
10 clicks x average CPC from Keyword Planner = minimum daily budget
example: 10 x $6 = $60 a day, about $1,800 a month
```

If the budget is lower, cut the keyword list and locations down to the most valuable ones rather than spreading thin.

## Landing pages

Every industry file has its own checklist. These apply to all of them:

- One page per service, matching the ad. Don't send ads to the home page.
- Phone number and form visible without scrolling on mobile.
- Form asks only what you need to call back: name, phone, email, one question.
- Show proof: reviews, licence numbers, years in business, photos of real work.
- Page loads in under 3 seconds on mobile.
- Privacy policy linked, and policy-required disclaimers present.

## Weekly routine

1. Search terms report: add negatives for anything irrelevant, add new keywords from good terms.
2. Check conversions are still firing (look for days with zero).
3. Check spend against budget and pacing.
4. Look at cost per lead by campaign and ad group. Pause ad groups that spent 2 to 3 times the target cost per lead with no leads.
5. Check policy status and disapproved ads or assets.
6. Ask the client how the leads were. Lead quality matters more than lead count.

## Monthly routine

1. Ad copy: replace the lowest-performing headlines and descriptions.
2. Location and time-of-day report: cut areas and hours that never convert.
3. Device report.
4. Compare leads in Google Ads with leads in the CRM. Large gaps mean tracking problems.
5. Write a short report for the client: spend, leads, cost per lead, closed clients if known, what changed, what's next.

## Policy basics

- Complete advertiser verification early. Several restricted categories require it.
- Read the policy notes in the industry file before writing ads. Some industries need certification before ads can run at all.
- If an ad is disapproved, fix the ad and landing page first, then appeal. Repeat appeals without changes usually fail.
- Google changes policies often. Check the Google Ads policy change log before each new build.
