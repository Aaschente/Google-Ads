# Google Ads skills for service businesses

Industry playbooks for running Google Ads for local service businesses, written from real campaigns in Canada. Each folder is a skill you can load into Claude or another AI assistant, and each one also reads fine as a plain guide.

Every industry file covers keywords sorted into top, middle and bottom of funnel, negative keywords, customer biases to use in ads, ad copy within Google's character limits, assets, campaign structure, landing page checks, and the policy and regulator rules that get ads disapproved in that industry.

## What's inside

| Skill | For | Main policy issue covered |
| --- | --- | --- |
| [core](core/SKILL.md) | Every account: tracking, structure, bidding, budget, weekly routine | Advertiser verification, appeals |
| [funnel-and-psychology](funnel-and-psychology/SKILL.md) | Every account: top, middle and bottom of funnel keywords, how each affects conversion rate and ROAS, budget split, and customer biases in ads | Misleading claims (fake scarcity, fake urgency) |
| [immigration](immigration/SKILL.md) | Immigration consultants (RCIC) and immigration lawyers | Government documents and services policy (October 2026 update) |
| [mortgage](mortgage/SKILL.md) | Mortgage brokers and agents | Financial Services Verification coming to Canada in 2027, FSRA ad rules |
| [dental](dental/SKILL.md) | Dental clinics | Health limits on remarketing, RCDSO advertising rules |
| [accounting-bookkeeping](accounting-bookkeeping/SKILL.md) | Bookkeeping firms and accounting practices | "CPA" title use, assurance licensing, CRA look-alike ads |
| [snow-removal](snow-removal/SKILL.md) | Residential and commercial snow removal | Seasonal timing, storm-day budgets |

More industries are planned. See [Contributing](#contributing).

## How to use it

With Claude:

1. Download this repo as a zip, or copy the folders you need.
2. Add `core`, `funnel-and-psychology` and the industry folder as skills (in Claude Code, put them in your skills folder; in the Claude app, upload them under skills in settings).
3. Ask for what you need, for example "Build a Google Ads Search campaign for a dental clinic in Brampton with a $1,500 monthly budget."

Without an AI tool: open `core/SKILL.md`, then the industry file, and work through them as checklists.

## Check the ad copy

Every headline and description in this repo is checked against Google's limits (30 characters for headlines, 90 for descriptions):

```
python tools/check_ad_limits.py
```

The same check runs automatically on every pull request through GitHub Actions.

## Important

- Google changes its ad policies often. The policy notes here reflect November 2026. Check the Google Ads policy change log before every new build.
- Regulator notes (CICC, FSRA, RCDSO, CPA bodies) are a starting point, not legal advice. Confirm with the licensed professional you work for.
- Placeholders like `[City]` and `[Year]` must be replaced before ads go live.

## Contributing

Pull requests are welcome, especially new industries and policy updates. Please:

1. Copy the structure of an existing industry file.
2. Keep headlines at 30 characters and descriptions at 90, and run the checker.
3. Link the source for any policy claim.
4. Say whether the playbook comes from real campaigns or is a starting template.

## Author

Built by Aaschente, a digital marketer in Mississauga, Ontario, working on Google Ads, Meta Ads and SEO for service businesses.

## License

MIT. See [LICENSE](LICENSE).
