---
name: google-ads-snow-removal
description: Google Ads for residential and commercial snow removal companies in Canada and the northern US. Use with google-ads-core when building seasonal snow plowing, salting or snow contract campaigns.
---

# Google Ads for snow removal

Written for GTA snow removal companies running November to April. Load `core/SKILL.md` first.

Snow removal works on two clocks. Seasonal contracts sell before winter. One-time and emergency jobs sell during and right after storms. Build for both.

## Policy notes

Snow removal has no special Google Ads category restrictions. The usual risks:

- Local Services policy: in some areas Google requires advanced verification for local service businesses. Check the account's verification status before launch.
- Don't advertise "24/7" or "guaranteed by 7 a.m." unless the crew can actually do it. Misleading claims get disapproved and bring bad reviews.
- If the company offers salting, follow local rules on salt use and say what is included.

## What converts

| Conversion | Notes |
| --- | --- |
| Seasonal contract quote form | Main conversion from September to early December. Ask address, driveway size, residential or commercial |
| Phone call over 30 seconds | Storm-day calls are short and urgent; a lower minimum call length fits |
| Signed contract (offline import) | Best signal. Import from the CRM with contract value |
| Commercial RFP or site visit request | Track separately; much higher value |

## Season plan

| Phase | When (GTA) | Focus | Budget share |
| --- | --- | --- | --- |
| Pre-season | September to mid-November | Seasonal contracts, early-bird pricing | About 40% |
| Peak sign-up | Mid-November to mid-December | Contracts, "spots filling" messaging | About 30% |
| Storm season | Mid-December to March | One-time plowing, emergency, contract sign-ups for the rest of winter | About 30%, boosted on storm days |
| Shoulder | April | Pause or switch to spring cleanup and landscaping | Low |

Adjust dates for your city. The early-season contract push matters most because most homeowners lock in one company for the whole winter.

## Campaign structure

| Campaign | Ad groups |
| --- | --- |
| Residential contracts | Seasonal snow removal, snow plowing contract, driveway snow removal, snow removal prices |
| Commercial | Commercial snow removal, parking lot plowing, property management snow, salting and sanding |
| On-demand | One-time snow removal, emergency snow plowing, snow removal today |
| Brand | Company name |

Keep residential and commercial apart. Commercial jobs are worth much more and take longer to close.

## Keyword groups

```
snow removal [city]
snow removal near me
snow plowing [city]
snow plowing near me
seasonal snow removal
snow removal contract [city]
residential snow removal
driveway snow removal
driveway snow plowing
snow removal prices [city]
snow removal cost
commercial snow removal [city]
parking lot snow removal
parking lot plowing
snow and ice management
salting services [city]
one time snow removal
emergency snow removal
snow removal today
sidewalk snow removal
```

## Negative keywords

Add to the core universal list:

```
snow blower
snowblower
snow blower repair
snow blower for sale
snow shovel
snow plow for sale
plow blade
truck plow
snow removal jobs
plow driver jobs
snow shoveling jobs
city snow removal
municipal snow removal
snow removal schedule
when will my street be plowed
311
snow day
school closures
weather forecast
snow forecast
```

Notes:

- "city snow removal" and "when will my street be plowed" are people asking about municipal plowing. They won't hire a private company for the street.
- Equipment terms ("snow blower", "plow blade") are DIY buyers.

## Ad copy

Headlines (30 characters max):

```headlines
Snow Removal in [City]
Seasonal Snow Plowing
Book Before Spots Fill Up
Early-Bird Winter Pricing
Driveway Plowed by Morning
Residential & Commercial
Fixed Price for the Season
Salting Included
Get a Free Snow Quote
Fully Insured Snow Crews
Commercial Lot Plowing
One-Time Plowing Available
Call for Snow Removal Today
Serving the GTA Since [Year]
No Shoveling This Winter
```

Descriptions (90 characters max):

```descriptions
One fixed price for the season. We plow after every snowfall so you don't have to.
Book before the first storm and lock in early-bird pricing. Limited routes in each area.
Commercial lots, plazas and condos. Plowing, salting and sidewalks on a set schedule.
Need it cleared now? Call for one-time snow removal. Insured crews across the GTA.
```

Swap "[City]" and "[Year]". Only use "plowed by morning" or "salting included" if the contract says so.

## Keyword funnel

See `funnel-and-psychology/SKILL.md` for the method and ROAS math.

| Stage | Example keywords | Landing page | What to expect |
| --- | --- | --- | --- |
| BOFU | snow removal [city], snow plowing contract, seasonal snow removal near me, commercial snow removal [city], snow removal today | Quote form page | Highest conversion rate, peaking September to December for contracts |
| MOFU | snow removal prices [city], seasonal snow removal cost, best snow removal company [city], snow removal reviews | Pricing page by driveway size | Price shoppers; publishing prices lifts conversion |
| TOFU | when does it snow in toronto, snow blower vs plowing service, how much snow is too much for a driveway | Seasonal guides | Almost no direct value. Skip in paid Search |

Snow removal ROAS depends on timing more than keywords. The same BOFU keyword can convert several times better in October than in February, because by February most homeowners have a contract. Front-load budget into the pre-season.

## Customer biases that work here

Homeowners want to stop worrying about winter mornings.

| Bias | How to use it here | Watch out |
| --- | --- | --- |
| Real scarcity | Limited routes or spots per neighbourhood | Only if routes really fill |
| Real urgency | Early-bird pricing deadline, first-snowfall date | Real deadlines only |
| Loss aversion | Shovelling time, being late for work, slip risk | Keep it light |
| Anchoring | Show the per-visit price before the seasonal price | Both must be real prices |
| Framing | Price per week of winter instead of only the season total | Show the season total too |
| Zero-risk bias | Fixed seasonal price no matter how much it snows | Only if the contract says so |
| Social proof | Number of driveways on the route in that neighbourhood | Real numbers |

```headlines
Routes Filling in [Area]
Early-Bird Ends Nov 15
Never Shovel Again
One Price, Any Snowfall
About $X a Week All Winter
40 Neighbours Already Signed
```

Replace "[Area]", the date, "$X" and "40" with real figures before use.

## Assets

- Sitelinks: Residential Contracts, Commercial Snow, Pricing, Service Areas, One-Time Plowing, Get a Quote.
- Callouts: Fully Insured, Fixed Seasonal Price, Salting Available, Sidewalk Clearing, Local Crews, Pay in Installments (if true).
- Structured snippet "Services": Driveway Plowing, Sidewalks, Salting, Parking Lots, Condos, Plazas.
- Price assets: seasonal price "from $X" by driveway size, if the company publishes prices.

## Landing page checklist

- [ ] Seasonal price or "from" price by driveway size, or a clear free-quote offer
- [ ] What triggers a visit (for example, 2 cm or more) and what's included
- [ ] Service area map or list of neighbourhoods
- [ ] Insurance stated
- [ ] Quote form: address, driveway size, residential or commercial, phone
- [ ] Separate commercial page with a site-visit request form
- [ ] Photos of real crews and equipment

## Storm-day playbook

1. Check the forecast every morning in season. Raise budgets the day before and the day of a big storm.
2. Turn on the on-demand campaign only if the crew can take new one-time jobs. If routes are full, pause it.
3. Run call assets heavily and make sure someone answers.
4. After the storm, push "lock in the rest of the season" messages to people who called for one-time jobs.

Ad schedules and budget rules can automate part of this, but a person checking the weather catches what rules miss.

## Bidding and budget

- Most budget goes into September to mid-December. Don't save it all for storms; by January most homeowners already have a contract.
- Use Maximize conversions once the pre-season contract campaign has data. Storm traffic swings wildly, so keep tight budget caps on the on-demand campaign.
- Import signed contracts from the CRM with their value. A commercial contract can be worth many residential ones.

## Common mistakes

1. Starting ads after the first snowfall, when most contracts are already signed.
2. Advertising one-time plowing when routes are full, then not answering calls.
3. Mixing residential and commercial in one campaign.
4. Not blocking municipal plowing and equipment searches.
5. Targeting areas outside the plow routes.
