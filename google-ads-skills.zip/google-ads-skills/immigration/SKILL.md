---
name: google-ads-immigration
description: Google Ads for immigration consultants and immigration lawyers, written for Canada (RCIC and lawyer firms). Use with google-ads-core when building, fixing or auditing immigration campaigns, especially after Government documents and services policy flags.
---

# Google Ads for immigration services

Written from running campaigns for a GTA immigration consulting firm. Canada first, but most of it applies to the US, UK and Australia with local rule changes.

Load `core/SKILL.md` first. This file adds what is specific to immigration.

## The policy problem you will hit first

Immigration ads often get flagged under Google's **Government documents and services** policy. This is the biggest reason immigration campaigns stop running.

What the policy says, as of November 2026:

- Since 5 October 2026, only certified governments and authorized providers may run ads that promote direct acquisition of specific government documents and services. To count as authorized, your domain must be linked from an official government site that names you as an authorized provider.
- Advertisers who get flagged but don't actually promote government documents and services can apply to have their ads excluded from the scope of the policy.
- Applying for exclusion or certification requires Google's advertiser verification.
- Since 22 October 2025, Google adds a "Not a government website" disclosure to Search ads in these categories unless you are certified.

Sources: [Google policy page](https://support.google.com/adspolicy/answer/13156083), [Relevant Audience summary of the October 2026 change](https://www.relevantaudience.com/google-ads-en/google-ads-government-documents-services-policy-october-2026/).

What this means for a consultant or law firm: you are not selling the visa, permit or eTA. You sell advice and representation. Your ads, keywords and landing pages need to say that clearly, and then you apply for exclusion.

### Fix order when campaigns are flagged

1. Rewrite ads so the offer is the consultation or representation, never the document. "Talk to a Licensed Consultant" is fine. "Get Your Work Permit Fast" reads like you sell the permit.
2. Remove or rewrite keywords that look like document purchase: "apply for eta", "visa application form", "work permit application online", "passport renewal".
3. Clean the landing pages. No "Apply now" buttons that look like a government form. No government logos or maple-leaf imagery that suggests you are the government. State clearly that you are a private licensed firm and that government fees are separate.
4. Add the licence details: consultant name, CICC licence number (R + digits), and that the firm is not affiliated with IRCC.
5. Complete advertiser verification if it isn't done.
6. Apply for exclusion from the policy scope, describing the business as licensed immigration consulting and legal representation.
7. Appeal only after steps 1 to 6. Appeals with no changes usually fail.

### Regulator rules (Canada)

- Consultants are licensed by the College of Immigration and Citizenship Consultants (CICC). Read the CICC Code of Professional Conduct section on advertising before writing ads.
- Never promise approval or outcomes. "Guaranteed visa" or "100% success" breaks regulator rules and Google's misleading content policy.
- Use "licensed" only for actual licensees. Don't call a consultant a lawyer.
- Lawyers in Ontario follow the Law Society of Ontario's marketing rules instead. Check which applies to the firm.

This is not legal advice. Check the current rules with the firm's licensee.

## What converts

| Conversion | Notes |
| --- | --- |
| Booked consultation (paid or free) | Best signal. A paid consult filters out time-wasters |
| Phone call over 60 seconds | Most immigration leads call. Staff the phone during ad hours |
| Assessment or eligibility form | Good volume, lower quality. Follow up within an hour |
| CRS calculator or free tool use | Secondary only. Use for remarketing lists, not bidding |

The fastest win is usually not in the ads. Speed-to-contact and follow-up after the consultation decide whether leads turn into clients.

## Campaign structure

Split by program, because cost and client value differ a lot:

| Campaign | Ad groups |
| --- | --- |
| Work permits | Open work permit, spousal open work permit, LMIA work permit, PGWP, work permit extension, work permit refusal |
| Permanent residence | Express Entry, PNP (OINP and others), spousal sponsorship, parent and grandparent sponsorship, H&C |
| Study | Study permit, study permit extension, study to PR |
| Visitor and status | Visitor visa, visitor record, super visa, restoration of status, TRP |
| Refusals and appeals | Refusal by program, judicial review (lawyer only), procedural fairness letter |
| Brand | Firm name and consultant name |

If budget is small, start with the two programs the firm earns most from, plus brand.

## Keyword groups

Pair each service with a location or a professional term. Professional terms ("consultant", "lawyer", "help") signal someone looking for advice, which also keeps you clearer of the government documents policy.

```
immigration consultant [city]
immigration consultant near me
licensed immigration consultant
rcic [city]
immigration lawyer [city]
canadian immigration consultant
express entry consultant
express entry help
pnp consultant ontario
oinp consultant
spousal sponsorship consultant
spousal sponsorship lawyer
spousal open work permit help
work permit consultant
lmia consultant
pgwp extension help
study permit consultant
study permit refusal help
visa refusal consultant
visitor visa refusal help
super visa consultant
restoration of status help
h&c application consultant
immigration consultation [city]
```

## Negative keywords

Add to the core universal list:

```
ircc login
gckey
ircc portal
application status
processing time
processing times
check status
eta application
eta canada
apply eta
passport
passport renewal
pr card renewal form
citizenship test
citizenship test practice
ielts
celpip practice
forms download
imm 5257 pdf
government fee
fee payment
uci number
biometrics appointment
vfs
immigration news
draw results
crs score calculator
```

Notes:

- "processing time", "draw results" and "crs calculator" bring high traffic and few leads. Serve those people with free tools and SEO instead.
- Remove "pr card renewal form" from negatives only if the firm wants PR card renewal clients and the ads clearly offer help, not the card.
- "ielts" and "celpip" are useful negatives unless the firm also sells test prep.

## Ad copy

Headlines (30 characters max):

```headlines
Immigration Consultant, RCIC
Talk to an RCIC Today
Book a Consultation
Free 15-Min Phone Consult
Serving the GTA Since 2019
Work Permit Help in Ontario
Spousal Sponsorship Help
Express Entry Strategy Call
Refused? Get a Second Opinion
Clear Fees, No Surprises
Hindi, Punjabi & English
Same-Week Consultations
CICC Licensed Consultant
Private Firm, Not IRCC
Call for a Case Review
```

Descriptions (90 characters max):

```descriptions
Licensed consultants review your case and explain your options. Book a consultation today.
Work permits, PR, sponsorship and refusals. Private licensed firm, not part of IRCC.
Fixed fees in writing before you start. Government fees are separate and listed upfront.
Refused before? We review the refusal letter and tell you honestly what can be done next.
```

Edit the language and history lines to match the firm. Don't add success rates unless the firm can document them and the regulator allows it.

## Keyword funnel

See `funnel-and-psychology/SKILL.md` for the method and ROAS math.

| Stage | Example keywords | Landing page | What to expect |
| --- | --- | --- | --- |
| BOFU | immigration consultant [city], rcic near me, spousal sponsorship consultant, study permit refusal help, book immigration consultation | Service page with booking and phone | Highest conversion rate and ROAS. Start here |
| MOFU | immigration consultant fees, rcic vs lawyer, best immigration consultant ontario, spousal sponsorship cost, express entry consultant reviews | Fees page, "consultant or lawyer" page, reviews | Mid conversion rate. Good once BOFU is maxed |
| TOFU | express entry draw, crs score, how to get pr in canada, oinp streams, pgwp eligibility | CRS calculator, draws tracker, guides | Very low direct conversion. Use free tools and SEO; keep paid spend small and capped |

TOFU immigration terms get huge search volume and pull budget away fast. In most accounts they belong in organic content and free tools, not paid Search. Watch the government documents policy too: TOFU terms about applications and forms are the ones most likely to get flagged.

## Customer biases that work here

Immigration clients are making a high-stakes, emotional decision, often in a second language. Fear of refusal and fear of being scammed drive most of it.

| Bias | How to use it here | Watch out |
| --- | --- | --- |
| Authority | CICC licence number, consultant's name and photo, years in practice | Never imply a link to IRCC |
| Zero-risk bias | Free 15-minute call, fixed fees in writing | No outcome guarantees. Regulators ban them |
| Loss aversion | Cost of a refusal, lost status, missed deadlines | Keep it factual, not scary |
| Ambiguity aversion | List the steps, show fees, say who calls back and when | Government fees shown separately |
| Social proof | Number of families helped, reviews in the client's language | Real reviews only, with consent |
| Real urgency | Permit expiry dates, program intake deadlines | Only real dates |

```headlines
Permit Expiring Soon?
Avoid a Costly Refusal
Know Your Fees Upfront
Talk to a Licensed RCIC
Families Helped Since 2019
Free 15-Min Case Call
```

"Families Helped Since 2019" assumes the firm started in 2019. Change it to match.

## Assets

- Sitelinks: Book a Consultation, Work Permits, Permanent Residence, Sponsorship, Refusals, Fees, About Our Team.
- Callouts: CICC Licensed, Clear Fixed Fees, Languages spoken, Evening Appointments, Online Consultations.
- Structured snippet "Services": Work Permits, Express Entry, Sponsorship, Study Permits, Visitor Visas, Refusals.
- Call asset with forwarding number during staffed hours only.

## Landing page checklist

- [ ] Consultant name and CICC licence number visible
- [ ] Line stating the firm is private and not affiliated with IRCC or the Government of Canada
- [ ] Consultation offer and its price (or "free 15-minute call") above the fold
- [ ] Government fees listed separately from professional fees
- [ ] No government logos, no layout copying canada.ca
- [ ] No outcome guarantees anywhere, including reviews you display
- [ ] Booking link or form that asks program, country of residence and phone number
- [ ] Reviews from real clients with consent
- [ ] Languages spoken, if more than English

## Bidding and budget

- Start with Maximize clicks and a CPC cap, or Manual CPC, on the two strongest programs.
- Pull CPCs for your city from Keyword Planner. Immigration terms in large Canadian cities are competitive, so budget for fewer, better keywords rather than all programs at once.
- Move to Maximize conversions once you have 15 to 30 booked consultations or qualified calls in 30 days.
- Import retained clients from the CRM as an offline conversion. Many form leads never retain, and bidding on retained clients fixes that.

## Common mistakes

1. Ads and pages that look like a government service. This is what triggers the policy flag.
2. Counting CRS calculator use or tel: clicks as primary conversions. Bidding then chases tool users, not clients.
3. One campaign for every program. Spousal sponsorship and visitor visas have very different value.
4. No one answering the phone during ad hours.
5. Running Performance Max before Search is stable and tracking is clean.
6. Showing ads across Canada when the firm only consults in one province's time zone and language set. Online consultations make national targeting possible, but test it as a separate campaign.
