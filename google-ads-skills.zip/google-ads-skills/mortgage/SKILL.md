---
name: google-ads-mortgage
description: Google Ads for mortgage brokers and mortgage agents, written for Canada (Ontario FSRA rules). Use with google-ads-core when building or auditing mortgage, refinance or renewal campaigns.
---

# Google Ads for mortgage brokers and agents

Written from building Search campaigns for an Ontario mortgage comparison site and agent. Load `core/SKILL.md` first.

## Policy and regulator notes

Read these before writing a single ad.

### Google

- Mortgages are financial services. Google already requires Financial Services Verification in 42 countries and announced on 20 October 2026 that it will extend it to the US and Canada in early 2027. The covered products and deadlines had not been published when this was written. Watch the Google Ads policy change log and complete verification as soon as it opens. Source: [Google blog, Canada](https://blog.google/intl/en-ca/company-news/outreach-initiatives/financial-services-verification-united-states-canada/).
- Complete advertiser verification now. Financial services verification sits on top of it.
- Credit ads in the US and Canada can't be targeted by gender, age, parental status, marital status or postal code. Use city or radius targeting instead. Check the current personalized advertising policy before building audiences.
- Debt services (debt settlement, debt management plans) need separate Google certification in Canada. Don't mix debt consolidation messaging into mortgage ads unless the business is certified for it.

### Ontario (FSRA)

- Mortgage brokerages and agents are licensed by the Financial Services Regulatory Authority of Ontario.
- Ads should show the brokerage name and brokerage licence number. Agents advertise under their brokerage, not as a standalone business.
- Use the correct title. A Mortgage Agent Level 1 is not a "mortgage broker".
- If you show a rate, include the term, rate type, date and the conditions. Keep it current. A stale rate in an ad is misleading.

Other provinces have their own regulators (BCFSA in British Columbia, for example). This is not legal advice. Check with the brokerage's principal broker.

## What converts

| Conversion | Notes |
| --- | --- |
| Phone call over 60 seconds | Strongest signal for renewals and purchases |
| Pre-approval or application form | Ask purchase price range, timeline and province |
| Booked call | Good for renewals and refinances |
| Calculator use | Secondary only |

## Campaign structure

| Campaign | Ad groups |
| --- | --- |
| Purchase | First-time buyer, pre-approval, new construction, self-employed |
| Renewal | Mortgage renewal, switch lender at renewal, renewal rates |
| Refinance | Refinance, equity take-out, debt consolidation refinance (check debt services rules) |
| Specialty | Self-employed, bad credit or B-lender, private mortgage, new to Canada |
| Brand | Agent name and brokerage name |

Renewal is often the best campaign to start with. Many Canadian mortgages renew every five years, the intent is clear, and the borrower already qualifies.

## Keyword groups

```
mortgage broker [city]
mortgage broker near me
mortgage agent [city]
best mortgage rates ontario
mortgage rates [city]
5 year fixed mortgage rate
variable mortgage rate ontario
mortgage pre approval [city]
first time home buyer mortgage
mortgage renewal
mortgage renewal rates
switch mortgage at renewal
refinance mortgage ontario
home equity refinance
self employed mortgage
mortgage for new immigrants canada
b lender mortgage
private mortgage lender ontario
second mortgage [city]
```

## Negative keywords

Add to the core universal list:

```
mortgage agent course
mortgage agent license
mortgage broker course
mortgage broker exam
mortgage calculator excel
amortization schedule template
bank of canada announcement
interest rate news
rate forecast
housing market crash
td login
rbc login
scotiabank login
cibc login
bmo login
online banking
mortgage payment login
foreclosure listings
power of sale listings
rent to own
apartments for rent
```

Notes:

- Bank names: add "[bank] login" style negatives. Whether to bid on or block bare bank names is a strategy call. Bidding on them is allowed, but you can't use the bank's trademark in ad text.
- Keep "rates" terms. Rate shoppers are good mortgage leads.

## Ad copy

Headlines (30 characters max):

```headlines
Ontario Mortgage Broker
Compare 30+ Lenders at Once
Mortgage Renewal Coming Up?
Free Mortgage Review
Get Pre-Approved This Week
First-Time Buyer Mortgages
Self-Employed Mortgages
Switch Lenders at Renewal
Licensed Mortgage Agent
Call for Today's Rates
No Cost to Compare Options
Refinance Your Mortgage
Mortgages for Newcomers
Evening & Weekend Calls
Talk to a Mortgage Agent
```

Descriptions (90 characters max):

```descriptions
Compare rates from banks and lenders in one call. Licensed agent, Ontario brokerage.
Renewing soon? Don't just sign the bank's offer. We compare lenders before you decide.
First-time buyer, self-employed or new to Canada? We find lenders that fit your situation.
Free review of your mortgage options. Book a call or get a pre-approval started today.
```

Replace "30+ lenders" with the brokerage's real number. Add the brokerage name and licence number to the ad (a pinned headline or a description) or to every landing page, depending on the regulator's current guidance.

## Keyword funnel

See `funnel-and-psychology/SKILL.md` for the method and ROAS math.

| Stage | Example keywords | Landing page | What to expect |
| --- | --- | --- | --- |
| BOFU | mortgage broker [city], mortgage renewal broker, mortgage pre approval near me, refinance mortgage ontario, self employed mortgage broker | Service page with form and phone | Highest conversion rate. Renewal terms often give the best ROAS |
| MOFU | best 5 year fixed rate, mortgage rates ontario, broker vs bank mortgage, mortgage renewal options, fixed vs variable | Rates page (kept current), comparison page | Rate shoppers convert reasonably well if the page has a quick form |
| TOFU | how much house can i afford, first time home buyer incentive canada, stress test explained, what is a b lender, bank of canada rate | Affordability calculator, buyer guides | Low direct conversion. Long sales cycle; use calculators to collect emails |

Mortgage buyers can take months from first search to application. A 90-day conversion window and offline import of funded deals give a much truer ROAS than 30-day form counts.

## Customer biases that work here

Borrowers worry about overpaying and about being rejected.

| Bias | How to use it here | Watch out |
| --- | --- | --- |
| Loss aversion | Money lost by signing the bank's renewal offer without comparing | Use real, sourced figures or none |
| Anchoring | Show the bank's posted rate next to the rate you found | Rates must be current, with term and conditions |
| Zero-risk bias | Free review, no cost to compare (explain lender-paid fees) | Disclose how the agent is paid |
| Authority | Licence level, brokerage name and number, number of lenders | Correct title: agent vs broker |
| Social proof | Funded clients, reviews | Real reviews with consent |
| Real urgency | Renewal date window (lenders often allow early rate holds) | Don't invent rate deadlines |
| Framing | Monthly payment difference instead of only a rate difference | Show the math |

```headlines
Don't Auto-Renew With Bank
Compare Before You Sign
Renewing in 120 Days?
Free, No-Cost Rate Check
Lower Your Monthly Payment
Licensed Ontario Agent
```

"Renewing in 120 Days?" works if lenders the brokerage uses hold rates for about that long. Check before using.

## Assets

- Sitelinks: Renewals, First-Time Buyers, Refinance, Self-Employed, Today's Rates, Book a Call.
- Callouts: Licensed in Ontario, Compare Many Lenders, Free Consultation, Evening Appointments, Languages spoken.
- Structured snippet "Services": Purchase, Renewal, Refinance, Pre-Approval, Self-Employed, Private Lending.
- Price assets can work for rate display, but only if someone updates them when rates change.

## Landing page checklist

- [ ] Agent name, title (agent or broker, correct level) and brokerage name and licence number
- [ ] Rates shown with term, type, date and conditions, or no rates at all
- [ ] Short form: name, phone, purchase or renewal, timeline, province
- [ ] Mortgage calculator below the form, not instead of it
- [ ] Clear note on how the agent is paid (usually by the lender) if the page says "no cost"
- [ ] Reviews from real clients with consent
- [ ] Privacy policy that covers how credit and personal data are handled

## Bidding and budget

- Mortgage CPCs are high in large Canadian cities. Check Keyword Planner for your area before setting a budget.
- With a small budget, run only renewal and pre-approval in one city, plus brand.
- Use call-focused campaigns or call assets heavily. Mortgage buyers like to talk.
- Import funded deals from the CRM as offline conversions when you can. A funded mortgage is worth far more than a form fill.

## Common mistakes

1. Calling an agent a broker, or leaving out the brokerage name and licence number.
2. Advertising a rate that has changed.
3. Targeting by age or postal code, which credit ads in Canada don't allow.
4. Mixing debt consolidation offers into ads without the needed certification.
5. Sending all ads to a rate comparison page with no form or phone number above the fold.
6. Ignoring Financial Services Verification until ads stop running in 2027.
