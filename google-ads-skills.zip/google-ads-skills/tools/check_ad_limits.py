"""Check every ```headlines and ```descriptions block in the repo against Google Ads limits.

Headlines: 30 characters max. Descriptions: 90 characters max.
Lines with placeholders like [City] are measured as written; replace them before use.

Usage: python tools/check_ad_limits.py
Exit code 1 if any line is over the limit.
"""

import pathlib
import re
import sys

LIMITS = {"headlines": 30, "descriptions": 90}
BLOCK = re.compile(r"```(headlines|descriptions)\n(.*?)```", re.S)


def main() -> int:
    root = pathlib.Path(__file__).resolve().parent.parent
    problems = 0
    checked = 0
    for path in sorted(root.glob("*/SKILL.md")):
        text = path.read_text(encoding="utf-8")
        for kind, body in BLOCK.findall(text):
            limit = LIMITS[kind]
            for line in body.strip().splitlines():
                line = line.strip()
                if not line:
                    continue
                checked += 1
                if len(line) > limit:
                    problems += 1
                    rel = path.relative_to(root)
                    print(f"{rel}: {kind[:-1]} is {len(line)} chars (max {limit}): {line}")
    print(f"Checked {checked} lines, {problems} over the limit.")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
