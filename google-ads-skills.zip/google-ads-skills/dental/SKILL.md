---
name: google-ads-dental
description: Google Ads for dental clinics, written for Canada (Ontario RCDSO rules). Use with google-ads-core when building or auditing campaigns for general, emergency or cosmetic dentistry.
---

# Google Ads for dental clinics

Load `core/SKILL.md` first. This file adds what is specific to dental clinics.

## Policy and regulator notes

### Google

- Remarketing and audience targeting are limited for health. Google's personalized advertising policy doesn't allow ads that target or imply a person's health condition. Remarketing a general "book a check-up" message to past site visitors can be fine. Remarketing "Still thinking about implants?" or "Fix your missing teeth" is not.
- The same rule covers landing pages used for remarketing. A page about sleep apnea or sedation for anxious patients is about a condition.
- Users under 18 can't receive personalized ads of any kind.
- Search ads for general dental services are allowed. The restrictions are about targeting and wording, not about advertising dentistry.

Source: [Google, Health in personalized advertising](https://support.google.com/adspolicy/answer/16701855).

### Regulator (Ontario)

- Dentists in Ontario follow the Royal College of Dental Surgeons of Ontario (RCDSO) advertising rules. They restrict testimonials, claims of superiority ("best dentist"), guarantees and use of the word "specialist" for anyone who isn't a registered specialist.
- Check whether displaying Google reviews on the clinic's site counts as testimonials under the current rules before adding a review widget.
- Show prices accurately, including what a price does and doesn't include.

Other provinces have their own colleges. This is not legal advice. Check the current guidelines with the clinic.

## What converts

| Conversion | Notes |
| --- | --- |
| Online booking | Best. Connect the clinic's booking system (Dentrix, Jane, NexHealth, etc.) to a confirmation page or event |
| Phone call over 60 seconds | Most new patients still call. Staff the front desk during ad hours |
| New patient form | Ask insurance type, preferred time, reason for visit (general only) |
| Emergency call | Track separately if the clinic offers emergency visits |

## Campaign structure

| Campaign | Ad groups |
| --- | --- |
| New patients | Dentist near me, dentist [city], family dentist, accepting new patients, dentist open Saturday |
| Emergency | Emergency dentist, same-day dentist, toothache dentist, broken tooth |
| Insurance and government plans | Dentist accepting CDCP, direct billing dentist |
| Cosmetic and high value | Implants, Invisalign or clear aligners, veneers, whitening (separate campaign, separate budget) |
| Brand | Clinic name and dentist names |

Start with new patients and emergency. Cosmetic terms cost more and take longer to convert.

## Keyword groups

```
dentist near me
dentist [city]
dentist [neighbourhood]
family dentist [city]
dentist accepting new patients
new patient dentist
dentist open saturday
dentist open sunday
evening dentist
emergency dentist [city]
same day dentist
24 hour dentist
toothache dentist
dentist accepting cdcp
canadian dental care plan dentist
direct billing dentist
kids dentist [city]
dental implants [city]
invisalign [city]
teeth whitening [city]
dental cleaning [city]
```

## Negative keywords

Add to the core universal list:

```
dental hygienist jobs
dental assistant jobs
dental assistant course
dental school
dentistry program
dental receptionist
dental supplies
dental lab
dental insurance quote
cdcp application
cdcp eligibility
cdcp login
sun life cdcp
home remedy
toothache remedy
toothache medicine
dental chair for sale
veterinary dental
dog dentist
```

Notes:

- "cdcp application" and "cdcp login" are people applying for the plan, not looking for a dentist. Keep "dentist accepting cdcp".
- "toothache remedy" brings people who want to avoid the dentist. "toothache dentist" is a good keyword.

## Ad copy

Headlines (30 characters max):

```headlines
Dentist in [City]
Accepting New Patients
Book Your Visit Online
Same-Day Emergency Visits
Open Evenings & Saturdays
We Accept CDCP Patients
Direct Billing to Insurers
Family Dentist Near You
Gentle Care for All Ages
Free Parking On Site
Call to Book Today
Online Booking in 1 Minute
New Patient Exams
Kids Welcome
Walk-In Emergencies
```

Descriptions (90 characters max):

```descriptions
New patients welcome. Book online in a minute or call to find a time that suits your week.
Toothache or broken tooth? Same-day emergency visits when available. Call us first.
We accept CDCP and bill most insurance companies directly, so you pay less at the visit.
Family dental care for all ages. Evening and Saturday hours, free parking, easy booking.
```

Swap "[City]" before use. Don't write "best", "top-rated" or "painless" unless the regulator allows the claim and the clinic can back it up.

## Keyword funnel

See `funnel-and-psychology/SKILL.md` for the method and ROAS math.

| Stage | Example keywords | Landing page | What to expect |
| --- | --- | --- | --- |
| BOFU | dentist near me, emergency dentist [city], dentist accepting new patients, dentist open saturday, dentist accepting cdcp | New patient or emergency page with booking | Highest conversion rate. Most of the budget belongs here |
| MOFU | invisalign cost [city], dental implants cost, teeth whitening price, best dentist [neighbourhood], dentist reviews [city] | Pricing and treatment pages | Good for high-value treatments; longer decision time |
| TOFU | how to fix a chipped tooth, are dental implants worth it, gum pain causes, invisalign vs braces | Treatment guides | Low direct conversion. Health remarketing limits mean these visitors are hard to follow up |

Dental ROAS depends heavily on patient lifetime value. A new family patient can bring years of cleanings and treatment, so judge new-patient campaigns on lifetime value, not the first visit.

Because remarketing on health conditions isn't allowed, TOFU has less follow-up value in dental than in most industries. Keep it small.

## Customer biases that work here

Patients delay dental visits because of fear, cost and hassle.

| Bias | How to use it here | Watch out |
| --- | --- | --- |
| Ambiguity aversion | Show hours, insurance and CDCP acceptance, what a first visit includes | Prices must say what's included |
| Zero-risk bias | Direct billing so patients don't pay upfront, clear new patient process | No "painless" guarantees |
| Specificity | "Book in 1 minute", exact hours, parking details | Must be accurate |
| Default effect | Pre-select "new patient exam" in online booking | Let patients change it easily |
| Loss aversion | Unused insurance benefits before year-end | General wording; no condition-based remarketing |
| Social proof | Number of families served | RCDSO limits testimonials; check before showing reviews |

```headlines
Use Your Benefits by Dec 31
Direct Billing, Pay Less Now
Book Online in 1 Minute
Open Saturdays & Evenings
We Accept CDCP Patients
New Patient Exam Available
```

Many Canadian dental plans reset on January 1, but some use other plan years. Adjust the benefits message for the clinic's patients.

## Assets

- Sitelinks: New Patients, Emergency Visits, Book Online, Insurance & CDCP, Our Team, Hours & Location.
- Callouts: Accepting New Patients, Direct Billing, Evening Hours, Saturday Hours, Free Parking, Languages spoken.
- Structured snippet "Services": Cleanings, Fillings, Crowns, Root Canals, Implants, Whitening.
- Location asset from the clinic's Google Business Profile. Local dental searches lean on the map.

## Landing page checklist

- [ ] Book online button and phone number above the fold on mobile
- [ ] Hours, including evenings and weekends, near the top
- [ ] Insurance and CDCP acceptance stated clearly
- [ ] Dentist names and registration status; "specialist" only for registered specialists
- [ ] No superiority claims or guarantees
- [ ] Real photos of the clinic and team
- [ ] Separate emergency page for emergency ads
- [ ] Separate cosmetic pages; keep these out of remarketing lists if they describe conditions

## Bidding and budget

- Dental searches are very local. Target a radius around the clinic that patients will actually drive, often 5 to 10 km in a city.
- Run emergency ads during and slightly before opening hours. An emergency call at 11 p.m. that no one answers is wasted spend.
- Track bookings by type if the booking system allows it, so you know which ads bring new patients versus existing patients.

## Common mistakes

1. Remarketing with condition-based wording, which gets ads limited or disapproved.
2. "Best dentist in [city]" in ad copy.
3. Radius too wide, bringing people who won't travel.
4. Sending emergency searches to the home page.
5. Counting existing-patient bookings as new-patient conversions.
6. Running cosmetic campaigns on the same budget as new patients, where implants eat the budget.
